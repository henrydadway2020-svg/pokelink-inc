/* ══════════════════════════════════════════════════════════════
   firebase-init.js
   Rellena esto con la config de TU PROPIO proyecto de Firebase:
   Firebase Console → Configuración del proyecto → tus apps → Config.
   Es seguro que estas claves viajen en el cliente (así funciona
   Firebase); lo que protege tus datos son las Reglas de Seguridad
   de Firestore, no mantener esto en secreto.
══════════════════════════════════════════════════════════════ */
var firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "tu-proyecto.firebaseapp.com",
  projectId: "tu-proyecto",
  storageBucket: "tu-proyecto.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:xxxxxxxxxxxxxxxx"
};

firebase.initializeApp(firebaseConfig);

window.db = firebase.firestore();
window.auth = firebase.auth();

// Sesión anónima automática: cada pestaña/dispositivo obtiene un uid propio
// sin necesidad de que el jugador cree una cuenta para probar el juego.
window.authReady = firebase.auth().signInAnonymously()
  .then(function () {
    return new Promise(function (resolve) {
      var unsub = firebase.auth().onAuthStateChanged(function (user) {
        if (user) { unsub(); resolve(user); }
      });
    });
  })
  .catch(function (err) {
    console.error('Error de autenticación anónima:', err);
    alert('No se pudo conectar con Firebase. Revisa firebase-init.js y las reglas de tu proyecto.');
  });
