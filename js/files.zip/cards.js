/* ══════════════════════════════════════════════════════════════
   cards.js — Mazo placeholder 100% original.
   5 elementos ficticios con nombre, color y curva de poder propia.
   Reemplaza este archivo cuando tengas tus propias cartas/ilustraciones;
   el resto del juego solo espera objetos {id, name, element, power}.
══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var ELEMENTS = {
    ember:  { label: 'Ember',  color: '#e2542b' },
    tide:   { label: 'Tide',   color: '#2b7fe2' },
    root:   { label: 'Root',   color: '#3f9142' },
    spark:  { label: 'Spark',  color: '#d6b32e' },
    shade:  { label: 'Shade',  color: '#6b4fa0' }
  };

  // Curva de poder: varias copias de valores bajos, pocas de valores altos.
  var POWER_CURVE = [1, 1, 1, 2, 2, 2, 3, 3, 4, 5];

  function buildDeck() {
    var deck = [];
    var n = 0;
    Object.keys(ELEMENTS).forEach(function (key) {
      POWER_CURVE.forEach(function (power) {
        n++;
        deck.push({
          id: key + '-' + n,
          name: ELEMENTS[key].label + ' ' + power,
          element: key,
          power: power
        });
      });
    });
    return deck;
  }

  // Fisher-Yates
  function shuffle(arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a;
  }

  function newShuffledDeck() {
    return shuffle(buildDeck());
  }

  window.TCG_CARDS = {
    ELEMENTS: ELEMENTS,
    newShuffledDeck: newShuffledDeck
  };
})();
