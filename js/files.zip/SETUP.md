# Poner en marcha tu duelo online

## 1. Crea tu propio proyecto de Firebase
1. Ve a https://console.firebase.google.com y crea un proyecto nuevo (gratis).
2. Dentro del proyecto, ve a **Compilación → Firestore Database** → crea la base de datos (modo producción o prueba, cualquiera sirve para empezar).
3. Ve a **Compilación → Authentication** → pestaña **Sign-in method** → habilita **Anónimo**.
4. Ve a **Configuración del proyecto** (el engranaje) → baja hasta "Tus apps" → crea una app **Web** → copia el objeto `firebaseConfig` que te muestra.

## 2. Pega tu config
Abre `js/firebase-init.js` y reemplaza el objeto `firebaseConfig` por el que copiaste.

## 3. Reglas de seguridad de Firestore (mínimas para probar)
En Firestore → **Reglas**, pon esto para empezar (ábrelo a cualquiera con sesión anónima; luego lo puedes endurecer):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /rooms/{roomId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## 4. Pruébalo
Como es HTML/JS puro, solo necesitas servirlo (no puedes abrir `index.html` con doble clic por las restricciones de Firebase con `file://`). La forma más simple:

```bash
cd tcg
python3 -m http.server 8000
```

Abre `http://localhost:8000` en dos pestañas (o dos navegadores) para simular a los dos jugadores: en una crea la sala, copia el código, y en la otra únete con ese código.

## Qué sigue (ideas para expandir)
- Reglas reales de tu juego (costos de energía, ataques dirigidos a una carta del rival, habilidades especiales, etc.)
- Arte propio para las cartas (reemplaza `js/cards.js`)
- Reconexión si alguien cierra la pestaña a mitad de partida
- Un lobby público con lista de salas abiertas, en vez de compartir el código a mano
