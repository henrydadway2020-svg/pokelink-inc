/* ══════════════════════════════════════════════════════════════
   game.js — Lobby (crear/unirse a sala) + partida 1v1 sincronizada
   en tiempo real vía Firestore. Reglas del juego deliberadamente
   simples (jugar cartas al campo, atacar con el poder total, pasar
   turno) para que sirvan de esqueleto que puedas expandir.
══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var STARTING_LIFE = 20;
  var STARTING_HAND = 5;
  var LOG_MAX = 12;

  var els = {
    lobby: document.getElementById('lobby'),
    game: document.getElementById('game'),
    createBtn: document.getElementById('create-room-btn'),
    joinBtn: document.getElementById('join-room-btn'),
    joinInput: document.getElementById('join-room-input'),
    nameInput: document.getElementById('player-name-input'),
    roomCodeDisplay: document.getElementById('room-code-display'),
    waitingMsg: document.getElementById('waiting-msg'),
    lobbyError: document.getElementById('lobby-error'),

    turnBanner: document.getElementById('turn-banner'),
    myLife: document.getElementById('my-life'),
    oppLife: document.getElementById('opp-life'),
    myName: document.getElementById('my-name'),
    oppName: document.getElementById('opp-name'),
    myField: document.getElementById('my-field'),
    oppField: document.getElementById('opp-field'),
    myHand: document.getElementById('my-hand'),
    attackBtn: document.getElementById('attack-btn'),
    endTurnBtn: document.getElementById('end-turn-btn'),
    log: document.getElementById('log'),
  };

  var state = {
    roomId: null,
    mySlot: null,      // 'p1' | 'p2'
    unsub: null,
    room: null,
  };

  function elementColor(key) {
    var e = window.TCG_CARDS.ELEMENTS[key];
    return e ? e.color : '#666';
  }

  function cardNode(card, opts) {
    opts = opts || {};
    var d = document.createElement('div');
    d.className = 'card' + (opts.playable ? ' card--playable' : '');
    d.style.setProperty('--card-color', elementColor(card.element));
    d.innerHTML =
      '<div class="card-power">' + card.power + '</div>' +
      '<div class="card-name">' + escapeHtml(card.name) + '</div>';
    if (opts.onClick) d.addEventListener('click', opts.onClick);
    return d;
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function fieldPower(cards) {
    return (cards || []).reduce(function (sum, c) { return sum + c.power; }, 0);
  }

  function roomRef(id) { return window.db.collection('rooms').doc(id); }

  function randomRoomCode() {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sin caracteres ambiguos
    var code = '';
    for (var i = 0; i < 5; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
    return code;
  }

  // ── Lobby: crear sala ──────────────────────────────────────────
  els.createBtn.addEventListener('click', function () {
    var name = (els.nameInput.value || 'Jugador 1').trim();
    window.authReady.then(function (user) {
      var code = randomRoomCode();
      var deck = window.TCG_CARDS.newShuffledDeck();
      var hand = deck.splice(0, STARTING_HAND);
      roomRef(code).set({
        status: 'waiting',
        turn: 'p1',
        winner: null,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        p1: { uid: user.uid, name: name, life: STARTING_LIFE, deck: deck, hand: hand, field: [] },
        p2: null,
        log: [logEntry(name + ' creó la sala.')]
      }).then(function () {
        state.roomId = code;
        state.mySlot = 'p1';
        els.roomCodeDisplay.textContent = code;
        els.waitingMsg.style.display = 'block';
        listenRoom(code);
      }).catch(function (err) { showLobbyError(err); });
    });
  });

  // ── Lobby: unirse a sala ───────────────────────────────────────
  els.joinBtn.addEventListener('click', function () {
    var name = (els.nameInput.value || 'Jugador 2').trim();
    var code = (els.joinInput.value || '').trim().toUpperCase();
    if (!code) { showLobbyError('Escribe el código de la sala.'); return; }
    window.authReady.then(function (user) {
      var ref = roomRef(code);
      window.db.runTransaction(function (tx) {
        return tx.get(ref).then(function (doc) {
          if (!doc.exists) throw new Error('Esa sala no existe.');
          var room = doc.data();
          if (room.p2) throw new Error('Esa sala ya está llena.');
          var deck = window.TCG_CARDS.newShuffledDeck();
          var hand = deck.splice(0, STARTING_HAND);
          tx.update(ref, {
            p2: { uid: user.uid, name: name, life: STARTING_LIFE, deck: deck, hand: hand, field: [] },
            status: 'active',
            log: appendLog(room.log, name + ' se unió. ¡Comienza la partida!')
          });
        });
      }).then(function () {
        state.roomId = code;
        state.mySlot = 'p2';
        listenRoom(code);
      }).catch(function (err) { showLobbyError(err.message || String(err)); });
    });
  });

  function showLobbyError(msg) {
    els.lobbyError.textContent = typeof msg === 'string' ? msg : (msg.message || 'Error inesperado.');
    els.lobbyError.style.display = 'block';
  }

  function logEntry(text) { return { text: text, ts: Date.now() }; }
  function appendLog(log, text) {
    var next = (log || []).concat([logEntry(text)]);
    return next.slice(-LOG_MAX);
  }

  // ── Escucha en tiempo real de la sala ────────────────────────────
  function listenRoom(code) {
    if (state.unsub) state.unsub();
    state.unsub = roomRef(code).onSnapshot(function (doc) {
      if (!doc.exists) return;
      state.room = doc.data();
      render();
    }, function (err) {
      console.error('Error escuchando la sala:', err);
    });
  }

  // ── Acciones de juego (transacciones para evitar choques) ────────
  function playCard(cardId) {
    var ref = roomRef(state.roomId);
    var mySlot = state.mySlot;
    window.db.runTransaction(function (tx) {
      return tx.get(ref).then(function (doc) {
        var room = doc.data();
        if (room.turn !== mySlot) throw new Error('No es tu turno.');
        var me = room[mySlot];
        var idx = me.hand.findIndex(function (c) { return c.id === cardId; });
        if (idx < 0) throw new Error('Esa carta ya no está en tu mano.');
        var card = me.hand[idx];
        var newHand = me.hand.slice(0, idx).concat(me.hand.slice(idx + 1));
        var newField = me.field.concat([card]);
        var patch = {};
        patch[mySlot] = Object.assign({}, me, { hand: newHand, field: newField });
        patch.log = appendLog(room.log, me.name + ' jugó ' + card.name + '.');
        tx.update(ref, patch);
      });
    }).catch(function (err) { console.warn(err.message || err); });
  }

  function attack() {
    var ref = roomRef(state.roomId);
    var mySlot = state.mySlot;
    var oppSlot = mySlot === 'p1' ? 'p2' : 'p1';
    window.db.runTransaction(function (tx) {
      return tx.get(ref).then(function (doc) {
        var room = doc.data();
        if (room.turn !== mySlot) throw new Error('No es tu turno.');
        var me = room[mySlot];
        var opp = room[oppSlot];
        var dmg = fieldPower(me.field);
        if (dmg <= 0) throw new Error('No tienes cartas en el campo para atacar.');
        var newOppLife = opp.life - dmg;
        var patch = {};
        patch[oppSlot] = Object.assign({}, opp, { life: newOppLife });
        patch.log = appendLog(room.log, me.name + ' atacó por ' + dmg + '.');
        if (newOppLife <= 0) {
          patch.status = 'finished';
          patch.winner = mySlot;
          patch.log = appendLog(patch.log, me.name + ' ¡gana la partida!');
        }
        tx.update(ref, patch);
      });
    }).catch(function (err) { console.warn(err.message || err); });
  }

  function endTurn() {
    var ref = roomRef(state.roomId);
    var mySlot = state.mySlot;
    var oppSlot = mySlot === 'p1' ? 'p2' : 'p1';
    window.db.runTransaction(function (tx) {
      return tx.get(ref).then(function (doc) {
        var room = doc.data();
        if (room.turn !== mySlot) throw new Error('No es tu turno.');
        var opp = room[oppSlot];
        var newOpp = opp;
        var log = room.log;
        if (opp.deck.length > 0) {
          var deck = opp.deck.slice();
          var drawn = deck.shift();
          newOpp = Object.assign({}, opp, { deck: deck, hand: opp.hand.concat([drawn]) });
          log = appendLog(log, opp.name + ' robó una carta.');
        }
        var patch = {};
        patch[oppSlot] = newOpp;
        patch.turn = oppSlot;
        patch.log = appendLog(log, 'Turno de ' + newOpp.name + '.');
        tx.update(ref, patch);
      });
    }).catch(function (err) { console.warn(err.message || err); });
  }

  els.attackBtn.addEventListener('click', attack);
  els.endTurnBtn.addEventListener('click', endTurn);

  // ── Render ────────────────────────────────────────────────────
  function render() {
    var room = state.room;
    if (!room) return;

    if (room.status === 'waiting') {
      els.waitingMsg.style.display = 'block';
      return;
    }

    els.lobby.style.display = 'none';
    els.game.style.display = 'block';

    var mySlot = state.mySlot;
    var oppSlot = mySlot === 'p1' ? 'p2' : 'p1';
    var me = room[mySlot];
    var opp = room[oppSlot];
    if (!me || !opp) return;

    els.myName.textContent = me.name;
    els.oppName.textContent = opp.name;
    els.myLife.textContent = me.life;
    els.oppLife.textContent = opp.life;

    var myTurn = room.turn === mySlot;
    els.turnBanner.textContent = room.status === 'finished'
      ? (room.winner === mySlot ? '¡Ganaste!' : 'Perdiste — ganó ' + opp.name)
      : (myTurn ? 'Tu turno' : 'Turno de ' + opp.name);
    els.turnBanner.classList.toggle('turn-banner--mine', myTurn && room.status !== 'finished');

    els.attackBtn.disabled = !myTurn || room.status === 'finished' || fieldPower(me.field) <= 0;
    els.endTurnBtn.disabled = !myTurn || room.status === 'finished';

    els.myField.innerHTML = '';
    me.field.forEach(function (c) { els.myField.appendChild(cardNode(c)); });

    els.oppField.innerHTML = '';
    opp.field.forEach(function (c) { els.oppField.appendChild(cardNode(c)); });

    els.myHand.innerHTML = '';
    me.hand.forEach(function (c) {
      els.myHand.appendChild(cardNode(c, {
        playable: myTurn && room.status !== 'finished',
        onClick: function () {
          if (myTurn && room.status !== 'finished') playCard(c.id);
        }
      }));
    });

    els.log.innerHTML = (room.log || []).slice().reverse()
      .map(function (l) { return '<div class="log-line">' + escapeHtml(l.text) + '</div>'; })
      .join('');
  }
})();
